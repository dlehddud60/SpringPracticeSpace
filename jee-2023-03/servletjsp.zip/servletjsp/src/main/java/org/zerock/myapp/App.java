package org.zerock.myapp;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class App {

	public static void main(String[] args) {
		log.info("하");
		

	} // main

} // end class
